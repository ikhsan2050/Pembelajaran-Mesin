import pandas as pd
from sklearn import preprocessing
data=pd.read_csv(r"C:\Users\User\Downloads\BenderlyZwick.csv")
df=pd.DataFrame(data)
min_max_scaler=preprocessing.MinMaxScaler()
np_scaled=min_max_scaler.fit_transform(df)
print("np_scaled:\n",np_scaled)
df_normalized=pd.DataFrame(np_scaled)
print("\n\ndf_normalized:\n",df_normalized)