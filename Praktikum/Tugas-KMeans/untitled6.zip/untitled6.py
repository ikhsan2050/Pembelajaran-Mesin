import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics.cluster import pair_confusion_matrix
from sklearn.preprocessing import StandardScaler
df = pd.read_csv(r"C:\Users\ACER\Downloads\FoodData_Central_foundation_food_csv_2021-10-28\sub_sample_food.csv")
df.info()

plt.figure(figsize=(6, 6))
plt.scatter(df['fdc_id'],df['fdc_id_of_sample_food'] )
plt.xlabel('fdc_id')
plt.ylabel('fdc_id_of_sample_food')

scaler = StandardScaler()
scaler.fit(df)
df_scaled = scaler.transform(df)

df_scaled = pd.DataFrame(df_scaled, columns=['fdc_id','fdc_id_of_sample_food'])


# try with k=2
y_pred = KMeans(n_clusters=2).fit_predict(df)
plt.scatter(df['fdc_id'],df['fdc_id_of_sample_food'], c=y_pred)
plt.title("Clustering Number of Blobs")
plt.show()

# trying to find the best number of clusters
Sum_of_squared_distances = []
K = range(1,15)
for k in K:
 km = KMeans(n_clusters=k)
 km = km.fit(df_scaled[['fdc_id','fdc_id_of_sample_food']])
 Sum_of_squared_distances.append(km.inertia_)

plt.plot(K, Sum_of_squared_distances, 'bx-')
plt.xlabel('k')
plt.ylabel('Sum_of_squared_distances')
plt.title('Elbow Method For Optimal k')
plt.show()

y_pred = KMeans(n_clusters=3).fit_predict(df)
plt.scatter(df['fdc_id'],df['fdc_id_of_sample_food'], c=y_pred)
plt.show()

pair_confusion_matrix(df['fdc_id_of_sample_food'],y_pred)
